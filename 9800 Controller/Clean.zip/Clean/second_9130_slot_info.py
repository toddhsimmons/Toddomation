import json
import re
from pprint import pprint
from ap_dict import ap_dbase
import time
import netmiko
import textfsm



start = time.time()
filename = 'apSlotInfo.txt'
outfile = 'apSlots.json'

# yaml_out = 'slots_yaml.yml'

ap_sep = r'=+\s*$'

ap_dict = {}
with open(filename, 'r') as t:
    slots_data =  t.read().splitlines()

end_of_file = len(slots_data) - 1

seperators = []
for i in range(len(slots_data)):
    if re.search(ap_sep, slots_data[i]):
       if i == 0:
           continue
       seperators.append(i)
seperators.append(end_of_file)

slot0 = []
for i in range(len(slots_data)):
    if slots_data[i] == 'Attributes for Slot 0':
        slot0.append(i)

slot1 = []
for i in range(len(slots_data)):
    if slots_data[i] == 'Attributes for Slot 1':
        slot1.append(i)

slot2 = []
for i in range(len(slots_data)):
    if slots_data[i] == 'Attributes for Slot 2':
        slot2.append(i)

current_ap = 0
slot0_index = slot0[current_ap]
slot1_index = slot1[current_ap]
slot2_index = slot2[current_ap]

for index, line in enumerate(slots_data):
    temp_line = line.strip()
    temp_entry = temp_line.split(': ', 1)
    re_ap_sep = re.findall(ap_sep, temp_line)

    if temp_line == ' ':
        continue

    if temp_entry == re_ap_sep:
        if index == 0:
            row = 1
            row_end = 47
            continue
                
        else:
            k = ap_dbase['Cisco AP Name']
            ap_dict[k] = ap_dbase
            ap_dbase = {}
            row = 1
            row_end = 47
            current_ap += 1
            slot0_index = slot0[current_ap]
            slot1_index = slot1[current_ap]
            slot2_index = slot2[current_ap]
            continue

    if row > 0 and row < row_end:
        if temp_line == 'AP CAPWAP-DTLS LSC Status' or temp_line == 'AP 802.1x LSC Status' or temp_line == 'Certificate status        : Not Available':
            row = row + 1
            continue
        if len(temp_entry)  == 1:
            row = row + 1
            row_end = row_end + 1
        else:
            key = temp_entry[0].strip(' ')
            value = temp_entry[1].strip(' ')
            ap_dbase[key] = value
            row = row + 1

    if index >= slot0_index and index < slot1_index:
        if temp_line == 'Attributes for Slot 0':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 11
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0'] = slot0_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 11
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0'] = slot0_dict

        if temp_line == 'Station Configuration':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 6
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0']['Station Configuration'] = slot0_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 6
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0']['Station Configuration'] = slot0_dict

        if temp_line == 'Operation Rate Set':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 13
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0']['Station Configuration']['Operation Rate Set'] = slot0_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 13
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0']['Station Configuration']['Operation Rate Set'] = slot0_dict

        if temp_line == 'MCS Set':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 33
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0']['Station Configuration']['MCS Set'] = slot0_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 33
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0']['Station Configuration']['MCS Set'] = slot0_dict

        if temp_line == '802.11ax Parameters':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 6
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0']['Station Configuration']['802.11ax Parameters'] = slot0_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 6
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0']['Station Configuration']['802.11ax Parameters'] = slot0_dict

        if re.search(r'Beacon Period.*', temp_line):
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 0']['Station Configuration'][key] = value
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 0']['Station Configuration'][key] = value

        if re.search(r'Fragmentation Threshold.*', temp_line):
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 0']['Station Configuration'][key] = value
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 0']['Station Configuration'][key] = value

        if re.search(r'Multi Domain Capability Implemented.*', temp_line):
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 0']['Station Configuration'][key] = value
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 0']['Station Configuration'][key] = value

        if re.search(r'Multi Domain Capability Enabled.*', temp_line):
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 0']['Station Configuration'][key] = value
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 0']['Station Configuration'][key] = value

        if re.search(r'Country String.*', temp_line):
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 0']['Station Configuration'][key] = value
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 0']['Station Configuration'][key] = value

        if temp_line == 'Multi Domain Capability':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 4
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0']['Multi Domain Capability'] = slot0_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 4
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0']['Multi Domain Capability'] = slot0_dict

        if temp_line == 'MAC Operation Parameters':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 5
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0']['MAC Operation Parameters'] = slot0_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 5
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0']['MAC Operation Parameters'] = slot0_dict

        if temp_line == 'Tx Power':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                power_section = next_entry.split(': ', 1)
                power_levels = power_section[1].strip(' ')
                loop_number = int(power_levels) + 5
                x = 1
                while x < loop_number:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        loop_number += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0']['Tx Power'] = slot0_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                power_section = next_entry.split(': ', 1)
                power_levels = power_section[1].strip(' ')
                loop_number = int(power_levels) + 5
                x = 1
                while x < loop_number:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        loop_number += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0']['Tx Power'] = slot0_dict

        if temp_line == 'Phy OFDM Parameters':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 10
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0']['Phy OFDM Parameters'] = slot0_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 10
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0']['Phy OFDM Parameters'] = slot0_dict

        if temp_line == '802.11n Antennas':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 4
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0']['Phy OFDM Parameters']['802.11n Antennas'] = slot0_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 6
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0']['Phy OFDM Parameters']['802.11n Antennas'] = slot0_dict

        if temp_line == 'Performance Profile Parameters':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 6
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0']['Performance Profile Parameters'] = slot0_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 6
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0']['Performance Profile Parameters'] = slot0_dict

        if temp_line == 'CleanAir Management Information':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 8
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0']['CleanAir Management Information'] = slot0_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 8
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0']['CleanAir Management Information'] = slot0_dict

        if temp_line == 'Radio Extended Configurations':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 7
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0']['Radio Extended Configurations'] = slot0_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 7
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0']['Radio Extended Configurations'] = slot0_dict

        if temp_line == 'Rogue Containment Information':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 2
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0']['Rogue Containment Information'] = slot0_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 2
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0']['Rogue Containment Information'] = slot0_dict

        if temp_line == 'Management Frame Information':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 3
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0']['Management Frame Information'] = slot0_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot0_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 3
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot0_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 0']['Management Frame Information'] = slot0_dict

        if re.search(r'NDP capability.*', temp_line):
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 0'][key] = value
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 0'][key] = value

        if re.search(r'NDP mode.*', temp_line):
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 0'][key] = value
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 0'][key] = value

        if re.search(r'Beam Selection.*', temp_line):
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 0'][key] = value
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 0'][key] = value

    elif index >= slot1_index and index < slot2_index:
        if temp_line == 'Attributes for Slot 1':
            ap_dbase['Attributes for Slot 1'] = ''
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 15
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1'] = slot1_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 15
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1'] = slot1_dict

        if temp_line == 'Station Configuration':
            ap_dbase['Attributes for Slot 1']['Station Configuration'] = ''
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 6
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['Station Configuration'] = slot1_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 6
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['Station Configuration'] = slot1_dict

        if temp_line == 'Operation Rate Set':
            ap_dbase['Attributes for Slot 1']['Station Configuration']['Operation Rate Set'] = ''
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 9
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['Station Configuration']['Operation Rate Set'] = slot1_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 9
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['Station Configuration']['Operation Rate Set'] = slot1_dict

        if temp_line == 'MCS Set':
            ap_dbase['Attributes for Slot 1']['Station Configuration']['MCS Set'] = ''
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 33
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['Station Configuration']['MCS Set'] = slot1_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 33
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['Station Configuration']['MCS Set'] = slot1_dict

        if temp_line == '802.11ax Parameters':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 6
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['Station Configuration']['802.11ax Parameters'] = slot1_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 6
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['Station Configuration']['802.11ax Parameters'] = slot1_dict

        if re.search(r'Beacon Period.*', temp_line):
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 1']['Station Configuration'][key] = value
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 1']['Station Configuration'][key] = value

        if re.search(r'Fragmentation Threshold.*', temp_line):
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 1']['Station Configuration'][key] = value
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 1']['Station Configuration'][key] = value

        if re.search(r'Multi Domain Capability Implemented.*', temp_line):
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 1']['Station Configuration'][key] = value
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 1']['Station Configuration'][key] = value

        if re.search(r'Multi Domain Capability Enabled.*', temp_line):
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 1']['Station Configuration'][key] = value
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 1']['Station Configuration'][key] = value

        if re.search(r'Country String.*', temp_line):
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 1']['Station Configuration'][key] = value
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 1']['Station Configuration'][key] = value

        if temp_line == 'Multi Domain Capability':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 4
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['Multi Domain Capability'] = slot1_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 4
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['Multi Domain Capability'] = slot1_dict

        if temp_line == 'MAC Operation Parameters':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 5
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['MAC Operation Parameters'] = slot1_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 5
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['MAC Operation Parameters'] = slot1_dict

        if temp_line == 'Tx Power':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                power_section = next_entry.split(': ', 1)
                power_levels = power_section[1].strip(' ')
                loop_number = int(power_levels) + 5
                x = 1
                while x < loop_number:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        loop_number += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['Tx Power'] = slot1_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                power_section = next_entry.split(': ', 1)
                power_levels = power_section[1].strip(' ')
                loop_number = int(power_levels) + 5
                x = 1
                while x < loop_number:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        loop_number += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['Tx Power'] = slot1_dict

        if temp_line == 'Phy OFDM Parameters':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 10
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['Phy OFDM Parameters'] = slot1_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 10
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['Phy OFDM Parameters'] = slot1_dict

        if temp_line == '802.11n Antennas':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 4
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['Phy OFDM Parameters']['802.11n Antennas'] = slot1_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 6
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['Phy OFDM Parameters']['802.11n Antennas'] = slot1_dict

        if temp_line == 'Performance Profile Parameters':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 10
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['Performance Profile Parameters'] = slot1_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 10
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['Performance Profile Parameters'] = slot1_dict

        if temp_line == 'CleanAir Management Information':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 8
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['CleanAir Management Information'] = slot1_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 8
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['CleanAir Management Information'] = slot1_dict

        if temp_line == 'Radio Extended Configurations':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 7
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['Radio Extended Configurations'] = slot1_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 7
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['Radio Extended Configurations'] = slot1_dict

        if temp_line == 'Rogue Containment Information':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 2
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['Rogue Containment Information'] = slot1_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 2
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['Rogue Containment Information'] = slot1_dict

        if temp_line == 'Management Frame Information':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 3
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['Management Frame Information'] = slot1_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 3
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['Management Frame Information'] = slot1_dict

        if re.search(r'NDP capability.*', temp_line):
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 1'][key] = value
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 1'][key] = value

        if re.search(r'NDP mode.*', temp_line):
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 1'][key] = value
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 1'][key] = value

        if re.search(r'Beam Selection.*', temp_line):
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 1'][key] = value
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 1'][key] = value
                
        if temp_line == 'Zero Wait DFS Parameters':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 4
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['Zero Wait DFS Parameters'] = slot1_dict
                    
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot1_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 4
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot1_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 1']['Zero Wait DFS Parameters'] = slot1_dict
                
    elif index >= slot2_index and index <= seperators[current_ap]:
        if temp_line == 'Attributes for Slot 2':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 12
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2'] = slot2_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 12
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2'] = slot2_dict

        if temp_line == 'Station Configuration':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 6
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['Station Configuration'] = slot2_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 6
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['Station Configuration'] = slot2_dict

        if temp_line == 'Operation Rate Set':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 9
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['Station Configuration']['Operation Rate Set'] = slot2_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 9
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['Station Configuration']['Operation Rate Set'] = slot2_dict

        if temp_line == 'MCS Set':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 33
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['Station Configuration']['MCS Set'] = slot2_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 33
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['Station Configuration']['MCS Set'] = slot2_dict

        if temp_line == '802.11ax Parameters':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 6
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['Station Configuration']['802.11ax Parameters'] = slot2_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 6
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['Station Configuration']['802.11ax Parameters'] = slot2_dict

        if re.search(r'Beacon Period.*', temp_line):
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 2']['Station Configuration'][key] = value
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 2']['Station Configuration'][key] = value

        if re.search(r'Fragmentation Threshold.*', temp_line):
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 2']['Station Configuration'][key] = value
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 2']['Station Configuration'][key] = value

        if re.search(r'Multi Domain Capability Implemented.*', temp_line):
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 2']['Station Configuration'][key] = value
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 2']['Station Configuration'][key] = value

        if re.search(r'Multi Domain Capability Enabled.*', temp_line):
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 2']['Station Configuration'][key] = value
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 2']['Station Configuration'][key] = value

        if re.search(r'Country String.*', temp_line):
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 2']['Station Configuration'][key] = value
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 2']['Station Configuration'][key] = value

        if temp_line == 'Multi Domain Capability':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 4
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['Multi Domain Capability'] = slot2_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 4
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['Multi Domain Capability'] = slot2_dict

        if temp_line == 'MAC Operation Parameters':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 5
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['MAC Operation Parameters'] = slot2_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 5
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['MAC Operation Parameters'] = slot2_dict

        if temp_line == 'Tx Power':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                power_section = next_entry.split(': ', 1)
                power_levels = power_section[1].strip(' ')
                loop_number = int(power_levels) + 5
                x = 1
                while x < loop_number:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        loop_number += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['Tx Power'] = slot2_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                power_section = next_entry.split(': ', 1)
                power_levels = power_section[1].strip(' ')
                loop_number = int(power_levels) + 5
                x = 1
                while x < loop_number:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        loop_number += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['Tx Power'] = slot2_dict

        if temp_line == 'Phy OFDM Parameters':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 11
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['Phy OFDM Parameters'] = slot2_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 11
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['Phy OFDM Parameters'] = slot2_dict

        if temp_line == '802.11n Antennas':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 4
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['Phy OFDM Parameters']['802.11n Antennas'] = slot2_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 6
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['Phy OFDM Parameters']['802.11n Antennas'] = slot2_dict

        if temp_line == 'Performance Profile Parameters':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 10
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['Performance Profile Parameters'] = slot2_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 10
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['Performance Profile Parameters'] = slot2_dict

        if temp_line == 'CleanAir Management Information':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 8
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['CleanAir Management Information'] = slot2_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 8
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['CleanAir Management Information'] = slot2_dict

        if temp_line == 'Radio Extended Configurations':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 7
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['Radio Extended Configurations'] = slot2_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 7
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['Radio Extended Configurations'] = slot2_dict

        if temp_line == 'Rogue Containment Information':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 2
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['Rogue Containment Information'] = slot2_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 2
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['Rogue Containment Information'] = slot2_dict

        if temp_line == 'Management Frame Information':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 3
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['Management Frame Information'] = slot2_dict
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 3
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['Management Frame Information'] = slot2_dict

        if re.search(r'NDP capability.*', temp_line):
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 2'][key] = value
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 2'][key] = value

        if re.search(r'NDP mode.*', temp_line):
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 2'][key] = value
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 2'][key] = value

        if re.search(r'Beam Selection.*', temp_line):
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 2'][key] = value
                # if index == end_of_file:
                #     k = ap_dbase['Cisco AP Name']
                #     ap_dict[k] = ap_dbase
                    # break
            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                key = temp_entry[0].strip(' ')
                value = temp_entry[1].strip(' ')
                ap_dbase['Attributes for Slot 2'][key] = value
                # if index == end_of_file:
                #     k = ap_dbase['Cisco AP Name']
                #     ap_dict[k] = ap_dbase
                    # break
        
        if temp_line == 'Zero Wait DFS Parameters':
            if ap_dbase['AP Model'] == 'C9130AXI-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 4
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['Zero Wait DFS Parameters'] = slot2_dict

            elif ap_dbase['AP Model'] == 'C9130AXE-B':
                slot2_dict = {}
                next_entry = str(slots_data[index + 1])
                x = 1
                end = 4
                while x < end:
                    line_info = next_entry.split(': ', 1)
                    if len(line_info) == 1:
                        new_line = index + 1
                        end += 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                    else:
                        k = line_info[0].strip(' ')
                        v = line_info[1].strip(' ')
                        slot2_dict[k] = v
                        new_line = index + 1
                        next_entry = str(slots_data[new_line + x])
                        x = x + 1
                ap_dbase['Attributes for Slot 2']['Zero Wait DFS Parameters'] = slot2_dict
        
        if re.search(r'END OF FILE.*', temp_line):
            k = ap_dbase['Cisco AP Name']
            ap_dict[k] = ap_dbase
            break                

with open(outfile, 'wt') as j:
    json.dump(ap_dict, j, indent=4)

ethernet = "AP Ethernet.json"
# Load the input file to a variable
eth_file = open("AP Ethernet Stats.txt")
raw_text_data = eth_file.read()
eth_file.close()

template = open("ap_ethernet.template")
re_table = textfsm.TextFSM(template)
fsm_results = re_table.ParseText(raw_text_data)

# print(fsm_results)
eth_dict = {}
for line in fsm_results:
    temp_dict = {}
    ap = line[0]
    eth_dict[ap] = {}
    temp_dict['Status'] = line[2]
    temp_dict['Speed'] = line[3]
    temp_dict['Duplex'] = line[4]
    eth_dict[ap].update(temp_dict)

with open(ethernet, 'wt') as j:
    json.dump(eth_dict, j, indent=4)

end = time.time()
ap_count = len(ap_dict)
# print(f'Seperators equal:  {seperators}')
total_time = int(end-start)
print("\n\n")
print(f'{ap_count} APs were just processed')
print(f'It took {total_time} to parse the slots data')