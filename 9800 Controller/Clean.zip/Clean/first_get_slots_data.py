from netmiko import ConnectHandler
import time

device1 = {
    "host": "Controller_IP",
    "username": "username",
    "password": "password",
    "device_type": "cisco_ios",
}
slots_text = 'AP Slot Info.txt'
ether_text = "AP Ethernet Stats.txt"

net_connect = ConnectHandler(**device1)

start = time.time()

slot_data = net_connect.send_command('show ap config slots', read_timeout=500)
ether_data = net_connect.send_command('show ap ethernet statistics')
net_connect.disconnect()

with open(slots_text, 'wt') as f:
    for line in slot_data:
        f.write(line)
    f.write("END OF FILE")   

with open(ether_text, 'wt') as e:
    for line in ether_data:
        e.write(line)  
     

end = time.time()
total_time = int(end-start)

print(total_time)