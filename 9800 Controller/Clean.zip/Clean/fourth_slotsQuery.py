import re

def apNoSIA(data):
    results = []
    for ap, apConfig in data.items():
        apName = apConfig['Cisco AP Name']
        apMac = apConfig['MAC Address']
        apModel = apConfig['AP Model']
        for apKey, apValue in apConfig.items():
            if re.search(r'Attributes for Slot\s\d', apKey):  ### Here is how to get to the specific slots
                slotId = apKey
                for slotKey, slotValue in apValue.items():
                    if re.search(r'Phy OFDM Parameters', slotKey):
                        for phyKey, phyValue in slotValue.items():
                            if re.search(r'802.11n Antennas', phyKey):
                                for antennaKey, antennaValue in phyValue.items():
                                    if antennaKey == 'SIA Status':
                                        if re.search(r'.*Not.*', antennaValue):
                                            phyDict = (apName, apMac, antennaValue)
                                            results.append(phyDict)

    results = list(set(results))
    return(results)

def apDarts(data):
    results = []
    for ap, apConfig in data.items():
        apName = apConfig['Cisco AP Name']
        apMac = apConfig['MAC Address']
        apModel = apConfig['AP Model']
        for apKey, apValue in apConfig.items():
            if re.search(r'Attributes for Slot\s\d', apKey):  ### Here is how to get to the specific slots
                slotId = apKey
                for slotKey, slotValue in apValue.items():
                    if re.search(r'Phy OFDM Parameters', slotKey):
                        for phyKey, phyValue in slotValue.items():
                            if re.search(r'802.11n Antennas', phyKey):
                                for antennaKey, antennaValue in phyValue.items():
                                    if antennaKey == 'SIA Status':
                                        if re.search(r'^Present.*', antennaValue):
                                            phyDict = (apName, apMac, antennaValue)
                                            results.append(phyDict)
    results = list(set(results))
    return(results)

def apMarlin(data):
    results = []
    for ap, apConfig in data.items():
        apName = apConfig['Cisco AP Name']
        apMac = apConfig['MAC Address']
        apModel = apConfig['AP Model']
        for apKey, apValue in apConfig.items():
            if re.search(r'Attributes for Slot\s\d', apKey):  ### Here is how to get to the specific slots
                slotId = apKey
                for slotKey, slotValue in apValue.items():
                    if re.search(r'Phy OFDM Parameters', slotKey):
                        for phyKey, phyValue in slotValue.items():
                            if re.search(r'802.11n Antennas', phyKey):
                                for antennaKey, antennaValue in phyValue.items():
                                    if antennaKey == 'SIA Product ID':
                                        if re.search(r'^C-ANT9104', antennaValue):
                                            phyDict = (apName, apMac, antennaValue)
                                            results.append(phyDict)
    results = list(set(results))
    return(results)


def apNoRxop(data):
    results = []
    for ap, apConfig in data.items():
        apName = apConfig['Cisco AP Name']
        apMac = apConfig['MAC Address']
        apModel = apConfig['AP Model']
        for apKey, apValue in apConfig.items():
            if re.search(r'Attributes for Slot\s\d', apKey):  ### Here is how to get to the specific slots
                slotId = apKey
                for slotKey, slotValue in apValue.items():
                    if re.search(r'Radio Extended Configurations', slotKey):
                        for phyKey, phyValue in slotValue.items():
                            if phyKey == 'RX SOP threshold':
                                if re.search(r'DEFAULT', phyValue):
                                    phyDict = (apName, apMac, phyValue)
                                    results.append(phyDict)
    results = list(set(results))
    return(results)

def apRxop(data):
    results = []
    for ap, apConfig in data.items():
        apName = apConfig['Cisco AP Name']
        apMac = apConfig['MAC Address']
        apModel = apConfig['AP Model']
        for apKey, apValue in apConfig.items():
            if re.search(r'Attributes for Slot\s\d', apKey):  ### Here is how to get to the specific slots
                slotId = apKey
                for slotKey, slotValue in apValue.items():
                    if re.search(r'Radio Extended Configurations', slotKey):
                        for phyKey, phyValue in slotValue.items():
                            if phyKey == 'RX SOP threshold':
                                if phyValue != 'DEFAULT':
                                    phyDict = (apName, apMac, phyValue)
                                    results.append(phyDict)
    results = list(set(results))
    return(results)

def apNoCca(data):
    results = []
    for ap, apConfig in data.items():
        apName = apConfig['Cisco AP Name']
        apMac = apConfig['MAC Address']
        apModel = apConfig['AP Model']
        for apKey, apValue in apConfig.items():
            if re.search(r'Attributes for Slot\s\d', apKey):  ### Here is how to get to the specific slots
                slotId = apKey
                for slotKey, slotValue in apValue.items():
                    if re.search(r'Radio Extended Configurations', slotKey):
                        for phyKey, phyValue in slotValue.items():
                            if phyKey == 'CCA threshold':
                                if re.search(r'AUTO', phyValue):
                                    phyDict = (apName, apMac, phyValue)
                                    results.append(phyDict)
    results = list(set(results))
    return(results)

def apCca(data):
    results = []
    for ap, apConfig in data.items():
        apName = apConfig['Cisco AP Name']
        apMac = apConfig['MAC Address']
        apModel = apConfig['AP Model']
        for apKey, apValue in apConfig.items():
            if re.search(r'Attributes for Slot\s\d', apKey):  ### Here is how to get to the specific slots
                slotId = apKey
                for slotKey, slotValue in apValue.items():
                    if re.search(r'Radio Extended Configurations', slotKey):
                        for phyKey, phyValue in slotValue.items():
                            if phyKey == 'CCA threshold':
                                if phyValue != 'AUTO':
                                    phyDict = (apName, apMac, phyValue)
                                    results.append(phyDict)
    results = list(set(results))
    return(results)

def apEthernet(data):
    results = []
    ap_dict = {}
    for ap, apConfig in data.items():
        ethSpeed = apConfig['Speed']
        speed = re.findall(r'\d+', ethSpeed)
        ethernetSpeed = int(speed[0])
        duplex = apConfig['Duplex']
        ap_list = []
        if ethernetSpeed < 1000:  ### 
            ap_list = [ap,ethSpeed,duplex]
            results.append(ap_list)
      
    return(results)