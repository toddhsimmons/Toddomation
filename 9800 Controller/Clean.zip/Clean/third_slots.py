import json
import fourth_slotsQuery as slotsData
import re
import pandas as pd
from pprint import pprint

filename = 'apSlots.json'
ethernet = 'AP Ethernet.json'

with open(filename) as f:
    data = json.load(f)
    
with open(ethernet) as e:
    ethData = json.load(e)

dartHeaders = ['AP Name', 'AP Mac', 'SIA Status']
rxsopHeaders = ['AP Name', 'AP Mac', 'RX SOP Threshold']
ccaHeaders = ['AP Name', 'AP Mac', 'CCA Threshold']
marlinHeaders = ['AP Name', 'AP Mac', 'SIA Product']
ethHeaders = ['AP Name', 'Speed', 'Duplex']

print('Here are your options:')
print('Option 1:  9130AXE AP with NO DART')
print('Option 2:  9130AXE AP with With DART')
print('Option 3:  List all Marlin APs')
print('Option 4:  APs with default RXSOP')
print('Option 5:  APs that have RXSOP Set')
print('Option 6:  APs with default CCA')
print('Option 7:  APs that have CCA Set')
print('Option 8:  APs with Ethernet < 1000 Mbps')

option = input('Option Number -->  ')
# print(option)
optionNumber = int(option)
if optionNumber == 1:
    configInfo = slotsData.apNoSIA(data)
    if len(configInfo) == 0:
        print('#' * 50)
        print('Good Going - All External Antenna APs have a DART')
        print('#' * 50)
    if len(configInfo) < 10:
        entries = len(configInfo)
        print('There are only {} APs, do you want to print to screen or CSV?'.format(entries))
        print('Option 1: Print to screen')
        print('Option 2: Create CSV')
        print('Option 3:  Both')
        siaOption = input('Option Number -->  ')
        siaOption = int(siaOption)
        if siaOption == 1:
            pprint(configInfo)
        elif siaOption == 2:
            df = pd.DataFrame(configInfo, columns=dartHeaders)
            df.to_csv('AXE No Dart.csv', mode='w', index=False, header=True, sep=',')
        elif siaOption == 3:
            pprint(configInfo)
            df = pd.DataFrame(configInfo, columns=dartHeaders)
            df.to_csv('AXE No Dart.csv', mode='w', index=False, header=True, sep=',')
        elif siaOption not in [1,2,3]:
            print('Sorry, that was not an option')
    else:
        df = pd.DataFrame(configInfo, columns=dartHeaders)
        df.to_csv('AXE No Dart.csv', mode='w', index=False, header=True, sep=',')

if optionNumber == 2:
    configInfo = slotsData.apDarts(data)
    if len(configInfo) == 0:
        print('#' * 50)
        print('Looks like none of the APs have DARTs')
        print('#' * 50)
    else:
        df = pd.DataFrame(configInfo, columns=dartHeaders)
        df.to_csv('AXE Dart Info.csv', mode='w', index=False, header=True, sep=',')

if optionNumber == 3:
    configInfo = slotsData.apMarlin(data)
    if len(configInfo) == 0:
        print('#' * 50)
        print('Looks like there are no Marlins here')
        print('#' * 50)
    else:
        df = pd.DataFrame(configInfo, columns=marlinHeaders)
        df.to_csv('Marlin APs.csv', mode='w', index=False, header=True, sep=',')

if optionNumber == 4:
    configInfo = slotsData.apNoRxop(data)
    if len(configInfo) == 0:
        print('#' * 50)
        print('Looks like all APs have RXSOP set')
        print('#' * 50)
    else:
        df = pd.DataFrame(configInfo, columns=rxsopHeaders)
        df.to_csv('APs without RXSOP.csv', mode='w', index=False, header=True, sep=',')

if optionNumber == 5:
    configInfo = slotsData.apRxop(data)
    if len(configInfo) == 0:
        print('#' * 50)
        print('Looks like all APs still have a CCA of DEFAULT')
        print('#' * 50)
    else:
        df = pd.DataFrame(configInfo, columns=rxsopHeaders)
        df.to_csv('APs with RXSOP.csv', mode='w', index=False, header=True, sep=',')

if optionNumber == 6:
    configInfo = slotsData.apNoCca(data)
    if len(configInfo) == 0:
        print('#' * 50)
        print('Looks like all APs have CCA set')
        print('#' * 50)
    else:
        df = pd.DataFrame(configInfo, columns=ccaHeaders)
        df.to_csv('APs without CCA.csv', mode='w', index=False, header=True, sep=',')

if optionNumber == 7:
    configInfo = slotsData.apCca(data)
    if len(configInfo) == 0:
        print('#' * 50)
        print('Looks like all APs still have a CCA of AUTO')
        print('#' * 50)
    else:
        df = pd.DataFrame(configInfo, columns=ccaHeaders)
        df.to_csv('APs with CCA.csv', mode='w', index=False, header=True, sep=',')

if optionNumber == 8:
    configInfo = slotsData.apEthernet(ethData)
    if len(configInfo) == 0:
        print('#' * 50)
        print('Looks like all APs have a good Ethernet connection')
        print('#' * 50)
    if len(configInfo) < 10:
        entries = len(configInfo)
        print('There are only {} APs, do you want to print to screen or CSV?'.format(entries))
        print('Option 1: Print to screen')
        print('Option 2: Create CSV')
        print('Option 3:  Both')
        siaOption = input('Option Number -->  ')
        siaOption = int(siaOption)
        if siaOption == 1:
            pprint(configInfo)
        elif siaOption == 2:
            df = pd.DataFrame(configInfo, columns=dartHeaders)
            df.to_csv('APs with Ethernet Issue.csv', mode='w', index=False, header=True, sep=',')
        elif siaOption == 3:
            pprint(configInfo)
            df = pd.DataFrame(configInfo, columns=dartHeaders)
            df.to_csv('APs with Ethernet Issue.csv', mode='w', index=False, header=True, sep=',')
        elif siaOption not in [1,2,3]:
            print('Sorry, that was not an option')
    else:
        df = pd.DataFrame(configInfo, columns=ethHeaders)
        df.to_csv('APs with Ethernet Issue.csv', mode='w', index=False, header=True, sep=',')

if optionNumber not in [1,2,3,4,5,6,7,8]:
    print('$' * 50)
    print('Sorry that was not a option')
    print('$' * 50)